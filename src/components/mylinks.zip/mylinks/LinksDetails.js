import React from 'react'

function LinksDetails() {
  return (
    <div style={{ outline: '3px solid red' }}>
      <h2>LinksDetails</h2>
    </div>
  )
}

export default LinksDetails
