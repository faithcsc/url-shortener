import React from 'react'
import LinksDetails from './LinksDetails'
import LinksList from './LinksList'
import LinkChart from './LinkChart'
import LinkMap from './LinkMap'

function LinksDisplay(props) {
  return (
    <div style={{ outline: '3px solid blue' }}>
      <LinksDetails />
      <LinksList />
      <LinkChart data={props.data} />
      <LinkMap />
    </div>
  )
}

export default LinksDisplay
