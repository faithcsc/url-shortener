import React from 'react'

function LinksMap() {
  return (
    <div style={{ outline: '3px solid red' }}>
      <h2>LinksMap</h2>
    </div>
  )
}

export default LinksMap
