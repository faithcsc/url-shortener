import React from 'react'

function LinksList() {
  return (
    <div style={{ outline: '3px solid red' }}>
      <h2>LinksList</h2>
      <ul>
        <li>Coffee</li>
        <li>Tea</li>
        <li>Milk</li>
      </ul>
    </div>
  )
}

export default LinksList
