import Cookies from 'js-cookie'
import config from '../../shared/config'
import makeRequest from '../../shared/requests'

// AUTHENTICATION

async function requestAuthToken(userData) {
  const sendUserData = {
    name: userData.name,
    email: userData.email,
    password: userData.sub,
    userid: userData.sub,
  }

  console.log(`sendUserData: ${JSON.stringify(sendUserData)}`)

  const response = await makeRequest(
    config.DB_ENDPOINTS.newuser,
    sendUserData,
    'application/json',
    'POST'
  )
  const idKey = 'id'
  if (idKey in response) {
    // user is in database
    Cookies.set('userid', response[idKey])
    const authToken = makeRequest(
      config.DB_ENDPOINTS.userauth,
      sendUserData,
      'application/json',
      'POST'
    )
    return authToken
  }
  return {}
}

const saveDictToCookie = (dict) => {
  Object.keys(dict).forEach((e) => Cookies.set(e, dict[e]))
}

const cookieExpiryDays = 1

async function onSuccessfulLogin(auth0data) {
  const { user } = auth0data
  user.datetime = Date.now()
  console.log(`user: ${JSON.stringify(user)}`)
  Cookies.set('user', user, {
    expires: cookieExpiryDays,
  })
  const authToken = await requestAuthToken(user)
  saveDictToCookie(authToken)
  return Cookies.get()
}

async function retrieveUserLinks(cookiesUser) {
  const { userid } = cookiesUser
  const userlinks = await makeRequest(
    config.DB_ENDPOINTS.userlinks + userid,
    {},
    '',
    'GET'
  )
  return userlinks
}

export {
  requestAuthToken,
  saveDictToCookie,
  onSuccessfulLogin,
  retrieveUserLinks,
}
